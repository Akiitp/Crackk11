package com.example.yoyoiq.Model;

public class The_Slide_Items_Model_Class {
    String Uri;

    public The_Slide_Items_Model_Class(String uri) {
        Uri = uri;
    }

    public String getUri() {
        return Uri;
    }

    public void setUri(String uri) {
        Uri = uri;
    }
}
