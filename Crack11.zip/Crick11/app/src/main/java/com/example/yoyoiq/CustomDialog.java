package com.example.yoyoiq;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class CustomDialog extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_custom_dialog);
    }
}