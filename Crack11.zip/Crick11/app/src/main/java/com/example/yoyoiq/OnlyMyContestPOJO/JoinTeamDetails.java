package com.example.yoyoiq.OnlyMyContestPOJO;

public class JoinTeamDetails {
}
