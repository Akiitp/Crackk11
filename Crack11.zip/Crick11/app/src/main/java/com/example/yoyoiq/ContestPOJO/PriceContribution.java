package com.example.yoyoiq.ContestPOJO;

public class PriceContribution {
    public String position;

    public PriceContribution(String position) {
        this.position = position;
    }

    public String getPosition() {
        return position;
    }

    public void setPosition(String position) {
        this.position = position;
    }
}
